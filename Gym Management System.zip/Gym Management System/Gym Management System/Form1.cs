﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gym_Management_System
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		DataHandler handler = new DataHandler();
		BindingSource src = new BindingSource();

		private void label4_Click(object sender, EventArgs e)
		{

		}

		private void btnRegister_Click(object sender, EventArgs e)
		{
			handler.Register(int.Parse(txtProgramId.Text), txtName.Text, txtDescription.Text, txtInstructor.Text, int.Parse(txtSchedule.Text), txtCapcity.Text, int.Parse(txtDuration.Text));
			
		}


		private void Form1_Load(object sender, EventArgs e)
		{
			// TODO: This line of code loads data into the 'trainProgramDataSet2.Program_Table' table. You can move, or remove it, as needed.
			this.program_TableTableAdapter1.Fill(this.trainProgramDataSet2.Program_Table);
			src.DataSource = handler.DisplayProgram();
			dataGridView1.DataSource = src;
		}

		private void txtDuration_TextChanged(object sender, EventArgs e)
		{

		}

		private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
			{
				dataGridView1.CurrentRow.Selected = true;

				txtProgramId.Text = dataGridView1.Rows[e.RowIndex].Cells["ProgramId"].FormattedValue.ToString();
				txtName.Text = dataGridView1.Rows[e.RowIndex].Cells["ProgramName"].FormattedValue.ToString();
				txtDescription.Text = dataGridView1.Rows[e.RowIndex].Cells["Description"].FormattedValue.ToString();
				txtInstructor.Text = dataGridView1.Rows[e.RowIndex].Cells["Instructor"].FormattedValue.ToString();
				txtSchedule.Text = dataGridView1.Rows[e.RowIndex].Cells["Schedule"].FormattedValue.ToString();
				txtCapcity.Text = dataGridView1.Rows[e.RowIndex].Cells["Capcity"].FormattedValue.ToString();
				txtDuration.Text = dataGridView1.Rows[e.RowIndex].Cells["Duration"].FormattedValue.ToString();
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			src.DataSource = handler.DisplayProgram();
			dataGridView1.DataSource = src;
		}

		private void button3_Click(object sender, EventArgs e)
		{
			src.MoveNext();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			src.MoveFirst();
		}

		private void btnMember_Click(object sender, EventArgs e)
		{
			Form2 f = new Form2();
			f.Show();
		}

		private void btnUpdate_Click(object sender, EventArgs e)
		{
			src.MovePrevious();
		}

		private void button4_Click(object sender, EventArgs e)
		{
			handler.Update(int.Parse(txtProgramId.Text), txtName.Text, txtDescription.Text, txtInstructor.Text, int.Parse(txtSchedule.Text), txtCapcity.Text, int.Parse(txtDuration.Text));

		}

		private void btnDelete_Click(object sender, EventArgs e)
		{
			handler.Delete(int.Parse(txtProgramId.Text));
		}
	}
}
