﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Gym_Management_System
{
    class DataHandler
    {
        public DataHandler() { }

        static string connect = @"Data Source=DESKTOP-5CN87TK\SQLEXPRESS;Initial Catalog=BelgiumCampusGym;Integrated Security=SSPI;";

        SqlConnection con;
        SqlCommand command;
        SqlDataAdapter adapter;

        public DataTable DisplayProgram()
        {
            string query = "SELECT * FROM TrainProgram";  // SQL query

            con = new SqlConnection(connect);
            adapter = new SqlDataAdapter(query, con);

            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        public DataTable DisplayMember()
        {
            string query = "SELECT * FROM Members";  // SQL query

            con = new SqlConnection(connect);
            adapter = new SqlDataAdapter(query, con);

            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        public void Register(int proID, string pn, string d, string it, int s, string c, int du)
        {
            try
            {
                string query = "INSERT INTO TrainProgram (ProgramID, ProgramName, Description, Instructor, Schedule, Capacity, Duration) VALUES (@ProgramID, @ProgramName, @Description, @Instructor, @Schedule, @Capacity, @Duration)";
                con = new SqlConnection(connect);
                con.Open();
                command = new SqlCommand(query, con);

                // Adding parameters to prevent SQL injection
                command.Parameters.AddWithValue("@ProgramID", proID);
                command.Parameters.AddWithValue("@ProgramName", pn);
                command.Parameters.AddWithValue("@Description", d);
                command.Parameters.AddWithValue("@Instructor", it);
                command.Parameters.AddWithValue("@Schedule", s);
                command.Parameters.AddWithValue("@Capacity", c);
                command.Parameters.AddWithValue("@Duration", du);

                command.ExecuteNonQuery();
                MessageBox.Show("Details saved");
            }
            catch (Exception e)
            {
                MessageBox.Show("Details not saved: " + e.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public void Update(int proID, string pn, string d, string it, int s, string c, int du)
        {
            try
            {
                string query = "UPDATE TrainProgram SET ProgramName = @ProgramName, Description = @Description, Instructor = @Instructor, Schedule = @Schedule, Capacity = @Capacity, Duration = @Duration WHERE ProgramID = @ProgramID";
                con = new SqlConnection(connect);
                con.Open();
                command = new SqlCommand(query, con);

                // Adding parameters to prevent SQL injection
                command.Parameters.AddWithValue("@ProgramID", proID);
                command.Parameters.AddWithValue("@ProgramName", pn);
                command.Parameters.AddWithValue("@Description", d);
                command.Parameters.AddWithValue("@Instructor", it);
                command.Parameters.AddWithValue("@Schedule", s);
                command.Parameters.AddWithValue("@Capacity", c);
                command.Parameters.AddWithValue("@Duration", du);

                command.ExecuteNonQuery();
                MessageBox.Show("Details updated");
            }
            catch (Exception e)
            {
                MessageBox.Show("Update was not saved: " + e.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public void Delete(int proID)
        {
            try
            {
                string query = "DELETE FROM TrainProgram WHERE ProgramID = @ProgramID";
                con = new SqlConnection(connect);
                con.Open();
                command = new SqlCommand(query, con);

                // Adding parameters to prevent SQL injection
                command.Parameters.AddWithValue("@ProgramID", proID);

                command.ExecuteNonQuery();
                MessageBox.Show("Details deleted");
            }
            catch (Exception e)
            {
                MessageBox.Show("Could not delete: " + e.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public void RegisterMember(int meID, string fs, string ln, DateTime dob, string g, int ph, string ad, string tp, DateTime st, DateTime ed)
        {
            try
            {
                string query = "INSERT INTO Members (MemberID, FirstName, LastName, DateOfBirth, Gender, Phone, Address, TrainingProgram, StartDate, EndDate) VALUES (@MemberID, @FirstName, @LastName, @DateOfBirth, @Gender, @Phone, @Address, @TrainingProgram, @StartDate, @EndDate)";
                con = new SqlConnection(connect);
                con.Open();
                command = new SqlCommand(query, con);

                // Adding parameters to prevent SQL injection
                command.Parameters.AddWithValue("@MemberID", meID);
                command.Parameters.AddWithValue("@FirstName", fs);
                command.Parameters.AddWithValue("@LastName", ln);
                command.Parameters.AddWithValue("@DateOfBirth", dob);
                command.Parameters.AddWithValue("@Gender", g);
                command.Parameters.AddWithValue("@Phone", ph);
                command.Parameters.AddWithValue("@Address", ad);
                command.Parameters.AddWithValue("@TrainingProgram", tp);
                command.Parameters.AddWithValue("@StartDate", st);
                command.Parameters.AddWithValue("@EndDate", ed);

                command.ExecuteNonQuery();
                MessageBox.Show("Member details saved");
            }
            catch (Exception e)
            {
                MessageBox.Show("Member details not saved: " + e.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public void UpdateMember(int meID, string fs, string ln, DateTime dob, string g, int ph, string ad, string tp, DateTime st, DateTime ed)
        {
            try
            {
                string query = "UPDATE Members SET FirstName = @FirstName, LastName = @LastName, DateOfBirth = @DateOfBirth, Gender = @Gender, Phone = @Phone, Address = @Address, TrainingProgram = @TrainingProgram, StartDate = @StartDate, EndDate = @EndDate WHERE MemberID = @MemberID";
                con = new SqlConnection(connect);
                con.Open();
                command = new SqlCommand(query, con);

                // Adding parameters to prevent SQL injection
                command.Parameters.AddWithValue("@MemberID", meID);
                command.Parameters.AddWithValue("@FirstName", fs);
                command.Parameters.AddWithValue("@LastName", ln);
                command.Parameters.AddWithValue("@DateOfBirth", dob);
                command.Parameters.AddWithValue("@Gender", g);
                command.Parameters.AddWithValue("@Phone", ph);
                command.Parameters.AddWithValue("@Address", ad);
                command.Parameters.AddWithValue("@TrainingProgram", tp);
                command.Parameters.AddWithValue("@StartDate", st);
                command.Parameters.AddWithValue("@EndDate", ed);

                command.ExecuteNonQuery();
                MessageBox.Show("Member details updated");
            }
            catch (Exception e)
            {
                MessageBox.Show("Update was not saved: " + e.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public void DeleteMember(int meID)
        {
            try
            {
                string query = "DELETE FROM Members WHERE MemberID = @MemberID";
                con = new SqlConnection(connect);
                con.Open();
                command = new SqlCommand(query, con);

                // Adding parameters to prevent SQL injection
                command.Parameters.AddWithValue("@MemberID", meID);

                command.ExecuteNonQuery();
                MessageBox.Show("Member details deleted");
            }
            catch (Exception e)
            {
                MessageBox.Show("Could not delete member: " + e.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
