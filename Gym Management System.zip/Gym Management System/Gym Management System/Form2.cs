﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gym_Management_System
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        DataHandler handler = new DataHandler();

        private void Form2_Load(object sender, EventArgs e)
        {
            LoadMembers();
        }

        private void LoadMembers()
        {
            listView1.Items.Clear();
            foreach (DataRow dr in handler.DisplayMember().Rows)
            {
                // Columns must match the column names in your Members table
                ListViewItem item = new ListViewItem(dr["MemberID"].ToString());
                item.SubItems.Add(dr["FirstName"].ToString());
                item.SubItems.Add(dr["LastName"].ToString());
                item.SubItems.Add(dr["DateOfBirth"].ToString());
                item.SubItems.Add(dr["Gender"].ToString());
                item.SubItems.Add(dr["PhoneNumber"].ToString());
                item.SubItems.Add(dr["Address"].ToString());
                item.SubItems.Add(dr["TrainingProgram"].ToString());
                item.SubItems.Add(dr["MembershipStartDate"].ToString());
                item.SubItems.Add(dr["MembershipEndDate"].ToString());

                listView1.Items.Add(item);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            LoadMembers();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Assuming textBox1 to textBox10 correspond to the member details
                int memberId = int.Parse(textBox1.Text);
                string firstName = textBox2.Text;
                string lastName = textBox3.Text;
                DateTime dateOfBirth = DateTime.Parse(textBox4.Text);
                string gender = textBox5.Text;
                int phoneNumber = int.Parse(textBox6.Text);
                string address = textBox7.Text;
                string trainingProgram = textBox8.Text;
                DateTime membershipStartDate = DateTime.Parse(textBox9.Text);
                DateTime membershipEndDate = DateTime.Parse(textBox10.Text);

                handler.RegisterMember(memberId, firstName, lastName, dateOfBirth, gender, phoneNumber, address, trainingProgram, membershipStartDate, membershipEndDate);
                LoadMembers();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error registering member: " + ex.Message);
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                textBox1.Text = item.SubItems[0].Text;
                textBox2.Text = item.SubItems[1].Text;
                textBox3.Text = item.SubItems[2].Text;
                textBox4.Text = item.SubItems[3].Text;
                textBox5.Text = item.SubItems[4].Text;
                textBox6.Text = item.SubItems[5].Text;
                textBox7.Text = item.SubItems[6].Text;
                textBox8.Text = item.SubItems[7].Text;
                textBox9.Text = item.SubItems[8].Text;
                textBox10.Text = item.SubItems[9].Text;
            }
        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                textBox1.Text = item.SubItems[0].Text;
                textBox2.Text = item.SubItems[1].Text;
                textBox3.Text = item.SubItems[2].Text;
                textBox4.Text = item.SubItems[3].Text;
                textBox5.Text = item.SubItems[4].Text;
                textBox6.Text = item.SubItems[5].Text;
                textBox7.Text = item.SubItems[6].Text;
                textBox8.Text = item.SubItems[7].Text;
                textBox9.Text = item.SubItems[8].Text;
                textBox10.Text = item.SubItems[9].Text;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                handler.DeleteMember(int.Parse(textBox1.Text));
                LoadMembers();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting member: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
