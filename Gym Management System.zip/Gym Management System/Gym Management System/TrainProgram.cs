﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gym_Management_System
{
	internal class TrainProgram
	{
		private int programID;
		private int schedule;
		private int duration;
		private string programname, description, instructor, capcity;

		public TrainProgram()
		{
		}

		public TrainProgram(int programID, int schedule, int duration, string programname, string description, string instructor, string capcity)
		{
			this.ProgramID = programID =;
			this.Schedule = schedule;
			this.Duration = duration;
			this.Programname = programname;
			this.Description = description;
			this.Instructor = instructor;
			this.Capcity = capcity;
		}

		public int ProgramID { get => programID; set => programID = value; }
		public int Schedule { get => schedule; set => schedule = value; }
		public int Duration { get => duration; set => duration = value; }
		public string Programname { get => programname; set => programname = value; }
		public string Description { get => description; set => description = value; }
		public string Instructor { get => instructor; set => instructor = value; }
		public string Capcity { get => capcity; set => capcity = value; }
	}
}
