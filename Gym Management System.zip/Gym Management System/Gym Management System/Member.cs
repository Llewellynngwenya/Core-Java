﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gym_Management_System
{
    internal class Member
    {
        private int memberID;
        private int phoneNumber;
        private int membershipStartDate;
        private int membershipEndDate;
        private string firstName, lastName, dateOfBirth, gender, address, trainingProgram;

        public Member()
        {
        }

        public Member(int memberID, string firstName, string lastName, string dateOfBirth, string gender, int phoneNumber, string address, string trainingProgram, int membershipStartDate, int membershipEndDate)
        {
            this.MemberID = memberID;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.DateOfBirth = dateOfBirth;
            this.Gender = gender;
            this.PhoneNumber = phoneNumber;
            this.Address = address;
            this.TrainingProgram = trainingProgram;
            this.MembershipStartDate = membershipStartDate;
            this.MembershipEndDate = membershipEndDate;
        }

        public int MemberID { get => memberID; set => memberID = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string DateOfBirth { get => dateOfBirth; set => dateOfBirth = value; }
        public string Gender { get => gender; set => gender = value; }
        public int PhoneNumber { get => phoneNumber; set => phoneNumber = value; }
        public string Address { get => address; set => address = value; }
        public string TrainingProgram { get => trainingProgram; set => trainingProgram = value; }
        public int MembershipStartDate { get => membershipStartDate; set => membershipStartDate = value; }
        public int MembershipEndDate { get => membershipEndDate; set => membershipEndDate = value; }
    }
}
